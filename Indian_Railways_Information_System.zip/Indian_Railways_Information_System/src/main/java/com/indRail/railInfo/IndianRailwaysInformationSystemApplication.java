package com.indRail.railInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndianRailwaysInformationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndianRailwaysInformationSystemApplication.class, args);
	}

}
